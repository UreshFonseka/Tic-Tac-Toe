let currentPlayer = "X";
let gameStatus = ["", "", "", "", "", "", "", "", ""];
let resultScreen = document.getElementById("result-screen");
let resultMessage = document.getElementById("result-message");
let currentPlayerDisplay = document.getElementById("current-player");

const winPatterns = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8], // rows
    [0, 3, 6], [1, 4, 7], [2, 5, 8], // columns
    [0, 4, 8], [2, 4, 6] // diagonals
];

function handleClick(cellIndex) {
    if (gameStatus[cellIndex] === "" && !checkWinner()) {
        gameStatus[cellIndex] = currentPlayer;
        renderBoard();
        if (!checkWinner() && !checkDraw()) {
            currentPlayer = currentPlayer === "X" ? "O" : "X";
            currentPlayerDisplay.innerText = `Current Player: ${currentPlayer}`;
        }
    }
}

function renderBoard() {
    const cells = document.querySelectorAll(".cell");
    cells.forEach((cell, index) => {
        cell.innerText = gameStatus[index];
    });
}

function checkWinner() {
    for (let pattern of winPatterns) {
        const [a, b, c] = pattern;
        if (gameStatus[a] !== "" && gameStatus[a] === gameStatus[b] && gameStatus[a] === gameStatus[c]) {
            resultMessage.innerHTML = `<p id="winner-message">Player ${gameStatus[a]} wins!</p><button onclick="resetGame()">New Game</button>`;
            showResultScreen();
            return true;
        }
    }
    return false;
}

function checkDraw() {
    if (!gameStatus.includes("")) {
        resultMessage.innerHTML = `<p id="winner-message">It's a draw!</p><button onclick="resetGame()">New Game</button>`;
        showResultScreen();
        return true;
    }
    return false;
}

function showResultScreen() {
    resultScreen.style.display = "flex";
    currentPlayerDisplay.style.display = "none";
}

function resetGame() {
    currentPlayer = "X";
    gameStatus = ["", "", "", "", "", "", "", "", ""];
    renderBoard();
    resultScreen.style.display = "none";
    currentPlayerDisplay.innerText = `Current Player: ${currentPlayer}`;
    currentPlayerDisplay.style.display = "block";
}
